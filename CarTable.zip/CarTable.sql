use Training_19Sep19_Pune
go

create table [46008575].Car
(
Id int identity(1,1) primary key,
Model Varchar(30) unique,
ManufacturerId int not null,
TypeId int not null,
Engine Varchar(30),
BHP Int not null,
TransmissionId int not null,
Mileage Int Not Null,
Seat Int Not Null,
AirBagDetails varchar(20) Not Null,
BootSpace int not null,
Price decimal not null
);
drop table [46008575].LoginDetails

select * from [46008575].Manufacturer

create table [46008575].Manufacturer
(
Id int identity(1,1) primary key,
ManufacturerName varchar(30) unique,
ContactPerson varchar(20) unique,
RegisteredOffice varchar(30) not null
);

create table [46008575].CarType
(
Id int identity(1,1) primary key,
CarType varchar(30) unique
);

create table [46008575].CarTransmissionType
(
Id int identity(1,1) primary key, 
TransmissionType varchar(20) unique
);

 create table [46008575].LoginDetails(
 userid varchar(20) primary key,
 password varchar(20) Not null );


 insert into [46008575].LoginDetails values('srija','srija07')
  insert into [46008575].LoginDetails values('abc','abc123')
 select * from [46008575].LoginDetails

