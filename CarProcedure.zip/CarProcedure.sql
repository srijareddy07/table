use [Training_19Sep19_Pune]
go
drop proc [46008575].DeleteCarDetails
create proc [46008575].AddCarDetails
(
@model varchar(20),
@MName varchar(20),
@Type Varchar(10),
@Engine varchar(4),
@BHP int,
@Transmission varchar(15),
@Mileage int,
@Seat int,
@AirBagDetails varchar(30),
@BootSpace int,
@price float
)
as
declare @MId int
select @MId=id from [46008575].Manufacturer where ManufacturerName=@MName
declare @TypeId int
select @TypeId=id from [46008575].CarType where CarType=@Type
declare @TId int 
select @TId=Id from [46008575].CarTransmissionType where TransmissionType=@Transmission

insert into [46008575].car values(@Model,@MId,@TypeId,@Engine,@BHP,@TId,@Mileage,@Seat,@AirBagDetails,@BootSpace,@Price)
go


create proc [46008575].UpdateCarDetails
(
@model varchar(20),
@MName varchar(20),
@Type Varchar(10),
@Engine varchar(4),
@BHP int,
@Transmission varchar(15),
@Mileage int,
@Seat int,
@AirBagDetails varchar(30),
@BootSpace int,
@price float
)
as
declare @MId int
select @MId=id from [46008575].Manufacturer where manufacturerName=@MName
declare @TypeId int
select @TypeId=id from [46008575].CarType where CarType=@Type
declare @TId int 
select @TId=Id from [46008575].CarTransmissionType where TransmissionType=@Transmission
update [46008575].Car set ManufacturerId=@MId,TypeId=@TypeId,Engine=@Engine,BHP=@BHP,TransmissionId=@TId,Mileage=@Mileage,
Seat=@Seat,AirBagDetails=@AirBagDetails,BootSpace=@BootSpace,Price=@Price where Model=@model
go

drop proc [46008575].SearchCarByname

create proc [46008575].SearchCarByModel
(
@model varchar(20)
)
as
select Model,ManufacturerName,CarType,Engine,BHP,TransmissionType,Mileage,AirBagDetails,BootSpace,Seat,Price from [46008575].Car   c
 inner join [46008575].Manufacturer m on c.ManufacturerId=m.Id 
 inner join [46008575].CarType ct on c.TypeId=ct.id
  inner join [46008575].CarTransmissionType ctt on c.TransmissionId=ctt.Id  
  where c.model=@model
go

create proc [46008575].SearchCarByname
(
@ManufacturerName varchar(20),
@CarType varchar(10)
)
as
select Model,ManufacturerName,CarType,Engine,BHP,TransmissionType,Mileage,Seat,AirBagDetails,BootSpace,Price from [46008575].Car  c
 inner join [46008575].Manufacturer m on c.ManufacturerId=m.Id 
 inner join [46008575].CarType ct on c.TypeId=ct.id
  inner join [46008575].CarTransmissionType ctt on c.TransmissionId=ctt.Id  
  where m.ManufacturerName=@ManufacturerName and ct.CarType=@CarType
 go

create proc [46008575].DeleteCarDetails
(
@model varchar(20)
)
as
delete from [46008575].Car where Model=@model
go

 create proc [46008575].CarList
as
select ManufacturerName,Model,CarType,Price from [46008575].Car c
inner join [46008575].Manufacturer m on c.ManufacturerId=m.id
 inner join [46008575].CarType ct on c.TypeId=ct.id
 go


  create proc [46008575].ValidateLogin(
 @userid varchar(20),
 @password varchar(20))
 as
 begin
 select * from  [46008575].LoginDetails where userid=@userid and password=@password
 end

